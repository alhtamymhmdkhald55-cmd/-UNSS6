package com.anis.unss;

import android.app.Activity;
import android.app.NotificationManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AdhanFullScreenActivity extends Activity {
    private int notificationId;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.rgb(3, 14, 43));
        getWindow().setNavigationBarColor(Color.rgb(3, 14, 43));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        notificationId = getIntent().getIntExtra("notificationId", 0);
        String prayer = getIntent().getStringExtra("prayer");
        if (prayer == null || prayer.isEmpty()) prayer = "الصلاة";
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(32), dp(24), dp(26));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(3, 13, 42), Color.rgb(8, 39, 91), Color.rgb(3, 16, 49)});
        root.setBackground(bg);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(112), dp(112));
        lpLogo.topMargin = dp(24); lpLogo.bottomMargin = dp(52);
        root.addView(logo, lpLogo);

        TextView title = new TextView(this);
        title.setText("حان موعد صلاة " + prayer);
        title.setTextColor(Color.WHITE); title.setTextSize(29); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("حان الآن موعد الأذان"); sub.setTextColor(Color.rgb(63, 202, 255));
        sub.setTextSize(27); sub.setTypeface(Typeface.DEFAULT, Typeface.BOLD); sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(36); subLp.bottomMargin = dp(20); root.addView(sub, subLp);

        View spacer = new View(this); root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));
        Button close = new Button(this); close.setText("×"); close.setTextColor(Color.WHITE); close.setTextSize(48);
        close.setAllCaps(false); close.setPadding(0, 0, 0, dp(8));
        GradientDrawable red = new GradientDrawable(); red.setColor(Color.rgb(235, 37, 65)); red.setShape(GradientDrawable.OVAL);
        close.setBackground(red); close.setElevation(dp(8));
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(116), dp(116));
        closeLp.bottomMargin = dp(14); root.addView(close, closeLp);
        close.setOnClickListener(v -> closeScreen());
        root.setOnClickListener(v -> { });
        setContentView(root);
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void closeScreen() {
        try { if (notificationId != 0) ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(notificationId); } catch (Exception ignored) {}
        finish();
    }
    @Override public void onBackPressed() { closeScreen(); }
}

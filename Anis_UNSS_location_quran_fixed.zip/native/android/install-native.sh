#!/usr/bin/env bash
set -euo pipefail
APP=android/app/src/main
PKG="$APP/java/com/anis/unss"
mkdir -p "$PKG"
cp native/android/*.java "$PKG/"
cat > "$PKG/MainActivity.java" <<'JAVA'
package com.anis.unss;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AdhanOverlayPlugin.class);
        registerPlugin(LocationPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
JAVA
python3 - <<'PY'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
perms=['ACCESS_COARSE_LOCATION','ACCESS_FINE_LOCATION','SCHEDULE_EXACT_ALARM','USE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','WAKE_LOCK','VIBRATE','POST_NOTIFICATIONS','USE_FULL_SCREEN_INTENT']
for perm in perms:
    line=f'    <uses-permission android:name="android.permission.{perm}" />'
    if line not in s:
        s=s.replace('<application', line+'\n    <application', 1)
activity='''        <activity
            android:name=".AdhanFullScreenActivity"
            android:exported="false"
            android:excludeFromRecents="true"
            android:launchMode="singleTop"
            android:showWhenLocked="true"
            android:turnScreenOn="true"
            android:theme="@android:style/Theme.Material.Light.NoActionBar" />
        <receiver
            android:name=".AdhanAlarmReceiver"
            android:enabled="true"
            android:exported="false" />
        <receiver
            android:name=".AdhanBootReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>
'''
if '.AdhanFullScreenActivity' not in s:
    s=s.replace('</application>', activity+'    </application>')
p.write_text(s)
PY
